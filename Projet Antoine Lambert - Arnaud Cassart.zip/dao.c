//
// Created by Antoine Lambert on 20-03-20.
//

#include "dao.h"
#include <stdio.h>
void test(){
    printf("DAO Connecté");
}