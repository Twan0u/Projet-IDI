# Projet - Introduction à la Data Intelligence
[![forthebadge](https://forthebadge.com/images/badges/made-with-c.svg)]()

[![ForTheBadge built-with-swag](http://ForTheBadge.com/images/badges/built-with-swag.svg)](https://GitHub.com/Naereen/)

Ce repository contient le code pour le projet du cours de Programmation Numérique dans le cadre de l'introduction à la data intelligence.

## Tests Unitaires

[![GitHub tag](https://img.shields.io/badge/Version-0.0.1-blue)]()

[![GitHub tag](https://img.shields.io/badge/Test Pass-100%-green)]()