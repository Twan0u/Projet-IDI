//
// Created by Antoine Lambert on 20-03-20.
//

#ifndef IDI_INTERFACELIB_H
#define IDI_INTERFACELIB_H
#include <stdio.h>

void line();
void title();
#endif //IDI_INTERFACELIB_H
